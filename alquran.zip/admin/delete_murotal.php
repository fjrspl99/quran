<?php 
session_start();
require_once 'includes/auth_validate.php';
require_once './config/config.php';
$del_id = filter_input(INPUT_POST, 'del_id');
if ($del_id && $_SERVER['REQUEST_METHOD'] == 'POST') 
{

	if($_SESSION['admin_type']!='super'){
		$_SESSION['failure'] = "Kamu Tidak Punya Hak Untuk Melakukan Aksi Ini";
    	header('location: sukamurotal.php');
        exit;

	}
    $murotal_id = $del_id;
    $db->where('id_murotal', $murotal_id);
    $status = $db->delete('murotal');
    
    if ($status) 
    {
        $_SESSION['info'] = "Menghapus Murotal Berhasil";
        header('location: sukamurotal.php');
        exit;
    }
    else
    {
    	$_SESSION['failure'] = "Tidak Dapat Menghapus Murotal Ini";
    	header('location: sukamurotal.php');
        exit;

    }
    
}