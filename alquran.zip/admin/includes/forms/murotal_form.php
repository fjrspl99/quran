<fieldset>
    <div class="form-group">
        <label for="id_murotal">Nomor Surat *</label>
          <input type="text" name="id_murotal" value="<?php echo $edit ? $murotal['id_murotal'] : ''; ?>" placeholder="Nomor Surat" class="form-control" required="required" id = "id_murotal" >
    </div> 

 <div class="form-group">
        <label>Reciter </label>
           <?php $opt_arr = array("Mishary Al-Afasy", "Syeikh Abdulrahman AL Ausiy", "Muhammad Thaha Al-Junyd", "Taqy Malik", "Muzammil Hasballah", "Ibrahim El-Haq", "Bayu Pratama", "Syeikh Abdul Rahman As-Sudais"); 
                            ?>
            <select name="nama_murotal" class="form-control selectpicker" required>
                <option value=" " >Pilih Reciter</option>
                <?php
                foreach ($opt_arr as $opt) {
                    if ($edit && $opt == $murotal['nama_murotal']) {
                        $sel = "selected";
                    } else {
                        $sel = "";
                    }
                    echo '<option value="'.$opt.'"' . $sel . '>' . $opt . '</option>';
                }

                ?>
            </select>
    </div>  
    <div class="form-group">
        <label for="surat_murotal">Nama Surat</label>
            <input  type="text" name="surat_murotal" value="<?php echo $edit ? $murotal['surat_murotal'] : ''; ?>" placeholder="Nama Surat" class="form-control" id="surat_murotal">
    </div>

    <div class="form-group">
        <label for="download_murotal">Link Directory File</label>
            <input type="text" name="download_murotal" value="<?php echo $edit ? $murotal['download_murotal'] : ''; ?>" placeholder="Link Murotal" class="form-control" value=
			type="text" id="download_murotal">
    </div> 
	<div id="notice"> Contoh Link : <img src="http://idquran.web.id/alquran/admin/includes/forms/fjrspl.png"></img></div> 
    <div class="form-group text-center">
        <label></label>
        <button type="submit" class="btn btn-warning" >Save <span class="glyphicon glyphicon-send"></span></button>
    </div>            
</fieldset>