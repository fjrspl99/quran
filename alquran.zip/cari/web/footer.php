                <div id="footer" <?php if(isset($num_doc_found) && $num_doc_found > 0) echo 'style="position: relative;"' ?>>
                    <div id="links">
                        <a href="http://idquran.web.id/alquran">IDQuran</a>
                        |
                        <a href="http://lafzi.apps.cs.ipb.ac.id/web/">Support Lafzi</a>
                        <?php /*|
                        <a href="http://abrari.wordpress.com/category/skripsi" target="_blank">Development Blog</a>
                        |
                        <a href="http://code.google.com/p/pencarian-fonetik-quran" target="_blank">Repositori Source Code</a>
                        */ ?>
                    </div>
                    <div id="copyright">
                        Copyright <?php echo date("Y"); ?> IPB
                    </div>
                </div>                
                
