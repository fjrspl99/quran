<?php
header("location:http://localhost/idquran/alquran/welcome/");
?>