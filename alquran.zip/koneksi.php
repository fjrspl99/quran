<?php
//buat koneksi dengan MySQL
$link=mysql_connect('localhost','idquranw_id','@fjrspl123','idquranw_id');
   
//jika koneksi gagal, langsung keluar dari PHP
if (!$link)
{
   die("Koneksi dengan MySQL gagal");
}
   
//gunakan database alquran
$result=mysql_query('use idquranw_id');
if (!$result)
{
   die("Muka Macem K*NT*L Mana Bisa");
}
//tampilkan tabel mahasiswa_ilkom
$result=mysql_query('SELECT * FROM visitor');
?>