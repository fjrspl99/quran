﻿<?php
//buat koneksi dengan MySQL
$link=mysql_connect('localhost','idquranw_id','@fjrspl123','idquranw_id');
   
//jika koneksi gagal, langsung keluar dari PHP
if (!$link)
{
   die("Koneksi dengan MySQL gagal");
}

//Simpan Data Statistik Website
    $ip      = $_SERVER['REMOTE_ADDR']; // Mendapatkan IP komputer user
    $tanggal = date("Ymd"); // Mendapatkan tanggal sekarang
    $waktu   = time(); // 
    // Mencek berdasarkan IPnya, apakah user sudah pernah mengakses hari ini 
    $s = mysql_query("SELECT * FROM pengunjung WHERE ip='$ip' AND tanggal='$tanggal'");
    // Kalau belum ada, simpan data user tersebut ke database
    if(mysql_num_rows($s) == 0){
    mysql_query("INSERT INTO pengunjung (ip, tanggal, hits, online) VALUES('$ip','$tanggal','1','$waktu')");
    } 
    else{
    mysql_query("UPDATE pengunjung SET hits=hits+1, online='$waktu' WHERE ip='$ip' AND tanggal='$tanggal'");
    }
   
//gunakan database alquran
$result=mysql_query('use idquranw_id');
if (!$result)
{
   die("Muka Macem K*NT*L Mana Bisa");
}
//tampilkan tabel mahasiswa_ilkom
$result=mysql_query('SELECT * FROM murotal');
?>

<!DOCTYPE html>
<html>
<head>
     <!-- TABLE STYLES-->
    <link href="css/dataTables.bootstrap.css" rel="stylesheet" />
    <link href="css/bootstrap.css" rel="stylesheet" />
	</script>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	
 	<title>IDQuran - Murotal</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
 	<meta name="description" content="Al-Quran Berbasis Online , Untuk memudahkan pengguna menghafal Al-Quran">
	<meta name="author" content="Fajar Saepul">
	<meta name="keywords" content="followers, likes, instagram, auto followers, followers gratis, followers indonesia, Admin Panel, Panel Gratis, Regarstore, Tools Gratis">
	<meta name="language" content="ID">
	<meta name="coverage" content="Worldwide">
	<meta name="distribution" content="Global">
	<meta name="google-site-verification" content="bCqjBiiwifBXrKB7pPbT3wMZGGBbUjuz6PUEtko06RA" />
	<link href="../gogram.net/assets/img/gogram.html" rel="icon" type="image/x-icon" />
 	<!-- Tell the browser to be responsive to screen width -->
 	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
 	<!-- Bootstrap 3.3.6 -->
 	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  	<!-- Font Awesome -->
 	<link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
 	<!-- Ionicons -->
 	<link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
 	<!-- Theme style -->
 	<link rel="stylesheet" href="assets/dist/css/AdminLTE.min.css">
 	<!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="assets/dist/css/skins/_all-skins.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="assets/plugins/iCheck/flat/blue.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="assets/plugins/morris/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="assets/plugins/jvectormap/jquery-jvectormap-1.2.2.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="assets/plugins/datepicker/datepicker3.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="assets/plugins/daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
	<link href='http://fonts.googleapis.com/css?family=Lato:400,900,700,700italic,400italic,300italic,300,100italic,100,900italic' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Dosis:400,500,700,800,600,300,200' rel='stylesheet' type='text/css'>
	<style>
			.highlight-one .bullet-one {
		  height: 150px;
		  background-size: cover;
		}
		.highlight-one .bullet-two {
		  margin-bottom: 5px;
		}
		.highlight-two {
		  max-width: 100px;
		  margin-top: -70px;
		  margin-bottom: 5px;
		  border: 3px solid #fff;
		  border-radius: 100%;
		  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
		}
		.bullet-two {
		  margin-top: 0;
		  margin-bottom: 0;
		  font-size: 16px;
		  color: inherit;
		}
		.compersation-one,
		.compersation-one:hover,
		.compersation-one:focus {
		  color: inherit;
		  text-decoration: inherit;
		}
		.bullet-two > a,
		.bullet-two > small,
		.bullet-two > small > a
		.highlight-one .bullet-two {
		  margin-bottom: 5px;
		}
		.list-one {
		  list-style: none;
		  padding: 0;
		}
		.ul-list {
		  display: inline-block;
		  padding: 0 10px;
		  border-right: 1px solid #d4dbe0;
		}
		.ul-list:last-child {
		  border-right: 0;
		}	
		
		@font-face {
  font-family: 'Uthmani';
  src : url('http://idquran.web.id/alquran/sources/font/UthmanicHafs1 Ver09.otf') format('truetype');
}
 
h3{
  background:#222;
  color:#f9f9f9;
   padding:5px;
}
 
.arabic{
    font-family: 'Uthmani', serif;
    font-size: 28px; font-weight: normal;
    direction:rtl;
    padding : 0 5px;
    margin : 0;
}
.arabic_number {
    font-size: 28px; font-weight: normal;
}
.arabic_center{
    font-family: 'Uthmani', serif;
    font-size: 28px; font-weight: normal;
    text-align:center;
    padding : 0 5px;
    margin : 0;
}
.latin {
    font-family: serif;
    font-size: 14px; font-weight: normal;
    direction:ltr;
    padding : 0;
    margin : 0;
}
.wadah-mengetik
{
	font-size: 22px;
	width: 740px;
	white-space:nowrap;
	overflow:hidden;
	-webkit-animation: ketik 5s steps(50, end);
	animation: ketik 5s steps(50, end);
}

@keyframes ketik{
		from { width: 0; }
}

@-webkit-keyframes ketik{
		from { width: 0; }
}
</style>
	<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">
 <header class="main-header">
    <nav class="navbar navbar-static-top">
      <div class="container">
        <div class="navbar-header">
         <a href="http://idquran.web.id/alquran/welcome/index.html" class="navbar-brand"><b>IDQuran</b>.web.id</a>
         <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
            <i class="fa fa-bars"></i>
          </button>
        </div>
            <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
                <ul class="nav navbar-nav">
                    <li ><a href="../quran.php"><i class="fa fa-book"></i>&nbsp;Al-Quran</a>
                    </li>
                    <li ><a href="../murotal/"><i class="fa fa-microphone"></i>&nbsp;Murotal</a>
                    </li>
                    <li ><a href="../cari"><i class="fa fa-search"></i>&nbsp;Pencarian Lafaz</a>
                    </li>
                    <li ><a href="http://idquran.web.id/quote"><i class="fa fa-quote"></i>&nbsp;Hadits Quote</a>
                    </li>                    
                    
                                   
                               </ul>
        </div>
      </div>
    </nav>
  </header>
</head>
<body>
  <div class="content-wrapper">
<div class="container">
    <div style="margin-top:50px;">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
				<center><p class="wadah-mengetik">Yuk Belajar Murotal - <b>FjrSpl</b></a></p></center>

						<div class="col-md-8 col-md-offset-2">
						</br></br></br></br>
						<div class="panel panel-primary">
						<div class="panel-body">
                            <div class="table">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
<tr>
   <th>Nomor Surat</th>
   <th>Reciter</th>
   <th>Nama Surat</th>
   <th>Download/Play</th>
</tr>
<?php
while ($row=mysql_fetch_array($result))
{
   echo "<tr>";
   echo "<td>".$row['id_murotal']."</td>";
   echo "<td>".$row['nama_murotal']."</td>";
   echo "<td>".$row['surat_murotal']."</td>";
   echo "<td>".$row['download_murotal']."</td>";  
   echo "</tr>";
}
?>
</table> 
                            </div>
                         </div>  
                        </div>
						</div>
    <script src="js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.dataTables.js"></script>
    <script src="js/dataTables.bootstrap.js"></script>
    <script>
            $(document).ready(function () {
                $('#dataTables-example').dataTable();
            });
    </script>
   
</body>
</html>
