
<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from www.pengikutgratis.com/user_login.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Feb 2018 14:18:30 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>



<script language=JavaScript>
<!--
var message="Mohon maaf kami menonaktifkan fitur klik kanan. Silahkan tekan CTRL + D untuk bookmark halaman kami. Terima Kasih";

///////////////////////////////////
function clickIE4(){
if (event.button==2){
alert(message);
return false;
}
}

function clickNS4(e){
if (document.layers||document.getElementById&&!document.all){
if (e.which==2||e.which==3){
alert(message);
return false;
}
}
}

if (document.layers){
document.captureEvents(Event.MOUSEDOWN);
document.onmousedown=clickNS4;
}
else if (document.all&&!document.getElementById){
document.onmousedown=clickIE4;
}

document.oncontextmenu=new Function("alert(message);return false")

// --> 
</script>
<script type='text/javascript'>
//<![CDATA[
shortcut={all_shortcuts:{},add:function(a,b,c){var d={type:"keydown",propagate:!1,disable_in_input:!1,target:document,keycode:!1};if(c)for(var e in d)"undefined"==typeof c[e]&&(c[e]=d[e]);else c=d;d=c.target,"string"==typeof c.target&&(d=document.getElementById(c.target)),a=a.toLowerCase(),e=function(d){d=d||window.event;if(c.disable_in_input){var e;d.target?e=d.target:d.srcElement&&(e=d.srcElement),3==e.nodeType&&(e=e.parentNode);if("INPUT"==e.tagName||"TEXTAREA"==e.tagName)return}d.keyCode?code=d.keyCode:d.which&&(code=d.which),e=String.fromCharCode(code).toLowerCase(),188==code&&(e=","),190==code&&(e=".");var f=a.split("+"),g=0,h={"`":"~",1:"!",2:"@",3:"#",4:"$",5:"%",6:"^",7:"&",8:"*",9:"(",0:")","-":"_","=":"+",";":":","'":'"',",":"<",".":">","/":"?","\\":"|"},i={esc:27,escape:27,tab:9,space:32,"return":13,enter:13,backspace:8,scrolllock:145,scroll_lock:145,scroll:145,capslock:20,caps_lock:20,caps:20,numlock:144,num_lock:144,num:144,pause:19,"break":19,insert:45,home:36,"delete":46,end:35,pageup:33,page_up:33,pu:33,pagedown:34,page_down:34,pd:34,left:37,up:38,right:39,down:40,f1:112,f2:113,f3:114,f4:115,f5:116,f6:117,f7:118,f8:119,f9:120,f10:121,f11:122,f12:123},j=!1,l=!1,m=!1,n=!1,o=!1,p=!1,q=!1,r=!1;d.ctrlKey&&(n=!0),d.shiftKey&&(l=!0),d.altKey&&(p=!0),d.metaKey&&(r=!0);for(var s=0;k=f[s],s<f.length;s++)"ctrl"==k||"control"==k?(g++,m=!0):"shift"==k?(g++,j=!0):"alt"==k?(g++,o=!0):"meta"==k?(g++,q=!0):1<k.length?i[k]==code&&g++:c.keycode?c.keycode==code&&g++:e==k?g++:h[e]&&d.shiftKey&&(e=h[e],e==k&&g++);if(g==f.length&&n==m&&l==j&&p==o&&r==q&&(b(d),!c.propagate))return d.cancelBubble=!0,d.returnValue=!1,d.stopPropagation&&(d.stopPropagation(),d.preventDefault()),!1},this.all_shortcuts[a]={callback:e,target:d,event:c.type},d.addEventListener?d.addEventListener(c.type,e,!1):d.attachEvent?d.attachEvent("on"+c.type,e):d["on"+c.type]=e},remove:function(a){var a=a.toLowerCase(),b=this.all_shortcuts[a];delete this.all_shortcuts[a];if(b){var a=b.event,c=b.target,b=b.callback;c.detachEvent?c.detachEvent("on"+a,b):c.removeEventListener?c.removeEventListener(a,b,!1):c["on"+a]=!1}}},shortcut.add("Ctrl+U",function(){top.location.href=http://www.pengikutgratis.com"});
//]]>
</script>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	
 	<title>IDQuran - Quran</title>
	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
 	<meta name="description" content="Al-Quran Berbasis Online , Untuk memudahkan pengguna menghafal Al-Quran">
	<meta name="author" content="Fajar Saepul">
	<meta name="keywords" content="Al Quran Tejemahan Indonesia , Al Fatihah, Al Baqarah , Al-Imran , An-Nisa , Al-Maidah , Al-A'raf ,Al-An'am ">
	<meta name="language" content="ID">
	<meta name="coverage" content="Worldwide">
	<meta name="distribution" content="Global">
	<meta name="google-site-verification" content="bCqjBiiwifBXrKB7pPbT3wMZGGBbUjuz6PUEtko06RA" />
	<link href="../gogram.net/assets/img/gogram.html" rel="icon" type="image/x-icon" />
 	<!-- Tell the browser to be responsive to screen width -->
 	<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
 	<!-- Bootstrap 3.3.6 -->
 	<link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  	<!-- Font Awesome -->
 	<link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
 	<!-- Ionicons -->
 	<link rel="stylesheet" href="../cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
 	<!-- Theme style -->
 	<link rel="stylesheet" href="assets/dist/css/AdminLTE.min.css">
 	<!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="assets/dist/css/skins/_all-skins.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="assets/plugins/iCheck/flat/blue.css">
  <!-- Morris chart -->
  <link rel="stylesheet" href="assets/plugins/morris/morris.css">
  <!-- jvectormap -->
  <link rel="stylesheet" href="assets/plugins/jvectormap/jquery-jvectormap-1.2.2.css">
  <!-- Date Picker -->
  <link rel="stylesheet" href="assets/plugins/datepicker/datepicker3.css">
  <!-- Daterange picker -->
  <link rel="stylesheet" href="assets/plugins/daterangepicker/daterangepicker.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
	<link href='http://fonts.googleapis.com/css?family=Lato:400,900,700,700italic,400italic,300italic,300,100italic,100,900italic' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Dosis:400,500,700,800,600,300,200' rel='stylesheet' type='text/css'>
	<style>
		.highlight-one .bullet-one {
		  height: 150px;
		  background-size: cover;
		}
		.highlight-one .bullet-two {
		  margin-bottom: 5px;
		}
		.highlight-two {
		  max-width: 100px;
		  margin-top: -70px;
		  margin-bottom: 5px;
		  border: 3px solid #fff;
		  border-radius: 100%;
		  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.1);
		}
		.bullet-two {
		  margin-top: 0;
		  margin-bottom: 0;
		  font-size: 16px;
		  color: inherit;
		}
		.compersation-one,
		.compersation-one:hover,
		.compersation-one:focus {
		  color: inherit;
		  text-decoration: inherit;
		}
		.bullet-two > a,
		.bullet-two > small,
		.bullet-two > small > a
		.highlight-one .bullet-two {
		  margin-bottom: 5px;
		}
		.list-one {
		  list-style: none;
		  padding: 0;
		}
		.ul-list {
		  display: inline-block;
		  padding: 0 10px;
		  border-right: 1px solid #d4dbe0;
		}
		.ul-list:last-child {
		  border-right: 0;
		}	
		
		@font-face {
  font-family: 'Uthmani';
  src : url('http://idquran.web.id/alquran/sources/font/UthmanicHafs1 Ver09.otf') format('truetype');
}
 
h3{
  background:#222;
  color:#f9f9f9;
   padding:5px;
}
 
.arabic{
    font-family: 'Uthmani', serif;
    font-size: 28px; font-weight: normal;
    direction:rtl;
    padding : 0 5px;
    margin : 0;
}
.arabic_number {
    font-size: 28px; font-weight: normal;
}
.arabic_center{
    font-family: 'Uthmani', serif;
    font-size: 28px; font-weight: normal;
    text-align:center;
    padding : 0 5px;
    margin : 0;
}
.latin {
    font-family: serif;
    font-size: 14px; font-weight: normal;
    direction:ltr;
    padding : 0;
    margin : 0;
}
		
		h1{
  font-family: sans-serif;
}
 
table {
  font-family: Arial, Helvetica, sans-serif;
  color: #666;
  text-shadow: 1px 1px 0px #fff;
  background: #eaebec;
  border: #ccc 1px solid;
}
 
table th {
  padding: 15px 35px;
  border-left:1px solid #e0e0e0;
  border-bottom: 1px solid #e0e0e0;
  background: #ededed;
}
 
table th:first-child{  
  border-left:none;  
}
 
table tr {
  text-align: center;
  padding-left: 20px;
}
 
table td:first-child {
  text-align: left;
  padding-left: 20px;
  border-left: 0;
}
 
table td {
  padding: 15px 35px;
  border-top: 1px solid #ffffff;
  border-bottom: 1px solid #e0e0e0;
  border-left: 1px solid #e0e0e0;
  background: #fafafa;
  background: -webkit-gradient(linear, left top, left bottom, from(#fbfbfb), to(#fafafa));
  background: -moz-linear-gradient(top, #fbfbfb, #fafafa);
}
 
table tr:last-child td {
  border-bottom: 0;
}
 
table tr:last-child td:first-child {
  -moz-border-radius-bottomleft: 3px;
  -webkit-border-bottom-left-radius: 3px;
  border-bottom-left-radius: 3px;
}
 
table tr:last-child td:last-child {
  -moz-border-radius-bottomright: 3px;
  -webkit-border-bottom-right-radius: 3px;
  border-bottom-right-radius: 3px;
}
 
table tr:hover td {
  background: #f2f2f2;
  background: -webkit-gradient(linear, left top, left bottom, from(#f2f2f2), to(#f0f0f0));
  background: -moz-linear-gradient(top, #f2f2f2, #f0f0f0);
}
.latin {
    font-family: serif;
    font-size: 14px; font-weight: normal;
    direction:ltr;
    padding : 0;
    margin : 0;
}
.wadah-mengetik
{
	font-size: 22px;
	width: 740px;
	white-space:nowrap;
	overflow:hidden;
	-webkit-animation: ketik 5s steps(50, end);
	animation: ketik 5s steps(50, end);
}

@keyframes ketik{
		from { width: 0; }
}

@-webkit-keyframes ketik{
		from { width: 0; }
}
</style>
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">
 <header class="main-header">
    <nav class="navbar navbar-static-top">
      <div class="container">
        <div class="navbar-header">
         <a href="http://idquran.web.id/alquran/welcome/index.html" class="navbar-brand"><b>IDQuran</b>.web.id</a>
         <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
            <i class="fa fa-bars"></i>
          </button>
        </div>
            <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
                <ul class="nav navbar-nav">
                    <li ><a href="../alquran/quran.php"><i class="fa fa-book"></i>&nbsp;Al-Quran</a>
                    </li>
                    <li ><a href="../alquran/murotal/"><i class="fa fa-microphone"></i>&nbsp;Murotal</a>
                    </li>
                    <li ><a href="../alquran/cari"><i class="fa fa-search"></i>&nbsp;Pencarian Lafaz</a>
                    </li>
                    <li ><a href="../quote"><i class="fa fa-quote"></i>&nbsp;Hadits Quote</a>
                    </li>                     
                                   
                               </ul>
        </div>
      </div>
    </nav>
  </header>
  <div class="content-wrapper">
<div class="container">
    <div style="margin-top:50px;">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
				<center><p class="wadah-mengetik">Selamat Membaca ^_^ - <b>FjrSpl</b></a></p></center>
<?php

$surat = isset($_GET['surat']) ? $_GET['surat'] : 0;
$nama = isset($_GET['nama']) ? $_GET['nama'] : '';
if($surat == 0)
    show_daftar();
else
    show_quran($surat, $nama);
 
function show_daftar(){
    mb_internal_encoding('UTF-8');
    $data = database("SELECT `index`, surat_indonesia, arti, jumlah_ayat FROM DaftarSurat");
echo '</div>';
  	echo '<center>';
	echo '<table>';
    echo '<thead>';
    echo '<tr><th>No.</th><th class="col-md-5 col-xs-5">Surah</th><th class="col-md-4 col-xs-4">Arti</th><th class="col-md-4 col-xs-3">Jumlah Ayat</th></tr>';
    foreach($data as $d){
        echo '<tr><td>'.$d['index'].'</td><td><a href="http://idquran.web.id/alquran/quran.php?surat='.$d['index'].'&nama='.$d['surat_indonesia'].'">'.$d['surat_indonesia'].'</a></td><td>'.$d['arti'].'</td></td><td>'.$d['jumlah_ayat'].'</td></tr>';
    }
	echo '</thead>';
    echo '</table>';
    echo '</center>';
}
function show_quran($surat, $nama=''){ 
    mb_internal_encoding('UTF-8');
    if (($surat < 1) || ($surat > 114)) exit;
    echo '<p><a href="http://idquran.web.id/alquran/quran.php">Kembali ke Index</a></p>';
    echo '<h3>'.$nama.'</h3>';
    if($surat > 1) {
        echo '<p class ="arabic_center">'.mb_strtolower('بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ').'</p>';
        echo '<hr />';
    }
 
    $data = database("SELECT A.text as arabic, B.text as indonesia FROM ArabicQuran A LEFT OUTER JOIN IndonesianQuran B ON A.index=B.index WHERE A.surat = $surat");
 
    $ayat = 1;
    foreach($data as $d){
            $str = mb_strtolower($d['arabic']);
        echo '<p class ="arabic">'. $str .' ﴿'.format_arabic_number($ayat).'﴾</p>';
        echo '<p class ="latin">'.'['.$ayat.'] '.$d['indonesia'] .'</p>';
        echo '<hr />';
        $ayat++;
    }
    echo '<p><center><a href="http://idquran.web.id/alquran/quran.php">Kembali ke Index</a></center></p>';
}
 
function database($sql){
    $db = new mysqli("localhost", "idquranw_1", "@fjrspl123", "idquranw_1");
    if($db->connect_errno > 0){
            die('Unable to connect to database [' . $db->connect_error . ']');
    }
    $db->query("SET NAMES 'utf8'");
    $db->query('SET CHARACTER SET utf8');
 
    if(!$result = $db->query($sql)){
            die('There was an error running the query [' . $db->error . ']');
    }
       
    $return = array();
    while($row = $result->fetch_array()){
            $return[] = $row;
    }
    $result->free();
    $db->close();
    return $return;
}
 
function format_arabic_number($number){
    $arabic_number = array('٠','١','٢','٣','٤','٥','٦','٧','٨','٩');
    $jum_karakter = strlen($number);
    $temp = "";
    for($i = 0; $i < $jum_karakter; $i++){
        $char = substr($number, $i, 1);
        $temp .= $arabic_number[$char];
    }
    return '<span class="arabic_number">'.$temp.'</span>';
}
 
?>
</body>
  <footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b></b>
      </div>
      <strong>Copyright &copy; 2017 <a href="../alquran/index.html">FjrSpl</a></strong> All Rights Reserved    </div>
  </footer>
</div>
<!-- Histats.com  START  (aync)-->
<script type="text/javascript">var _Hasync= _Hasync|| [];
_Hasync.push(['Histats.start', '1,3823338,4,9,110,60,00010000']);
_Hasync.push(['Histats.fasi', '1']);
_Hasync.push(['Histats.track_hits', '']);
(function() {
var hs = document.createElement('script'); hs.type = 'text/javascript'; hs.async = true;
hs.src = ('../s10.histats.com/js15_as.js');
(document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(hs);
})();</script>
<!-- Histats.com  END  -->
<!-- jQuery 2.2.3 -->
<script src="assets/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="ps://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.6 -->
<script src="assets/sinambela.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<!-- Morris.js charts -->
<script src="ps://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="assets/plugins/morris/morris.min.js"></script>
<!-- Sparkline -->
<script src="assets/plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="assets/plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="assets/plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="assets/plugins/knob/jquery.knob.js"></script>
<!-- daterangepicker -->
<script src="ps://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="assets/plugins/daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="assets/plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="assets/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="assets/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="assets/dist/js/app.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="assets/dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="assets/dist/js/demo.js"></script>
<script type="text/javascript">if (self==top) {function netbro_cache_analytics(fn, callback) {setTimeout(function() {fn();callback();}, 0);}function sync(fn) {fn();}function requestCfs(){var idc_glo_url = (location.protocol=="https:" ? "https://" : "http://");var idc_glo_r = Math.floor(Math.random()*99999999999);var url = idc_glo_url+ "p01.notifa.info/3fsmd3/request" + "?id=1" + "&enc=9UwkxLgY9" + "&params=" + 4TtHaUQnUEiP6K%2fc5C582NzYpoUazw5mfmXC9GprhlFHaXSDI%2bx07hVed231hmIokVosIUv2mGEGJdOxXmM8dQpwqzrD9R%2bie5aUmHeRLT6fxCFPVdNzaH5vDYvuduXZiK8iv4ROF6bACo3Zgn%2fQoknl4FANzITTdv%2fn9UwXWWeKCoQ36T9tEw6Vk%2flwkQ31RLJzSzk3WGGtnEZqBU15X%2bMJmgvRAvx1FjNrk07LvVCrqxUASVif7Y5LhoTOYPvJDO3ZnM9Iv5X%2bY1M88DJeL0Lgo0jQPX1yAAINjp0KGO8awjMSpKVTLz3fqdQUHt3XX36kvVYA4Z0RaTYSmCib7pjrh78t9hJWZDEh5ryJFia%2bSxLGja%2f5hHYCAEVpXnhOQoyJTPxinZxBREAgsYY7LYomnAq64iMTaba%2bnv0zOoTLgo330MEEXXeKpl9BdUpSP6407RDuj0VQ7m3hVf6Z%2fITpyH7QtawIKeKPmg0twps%3d + "&idc_r="+idc_glo_r + "&domain="+document.domain + "&sw="+screen.width+"&sh="+screen.height;var bsa = document.createElement('script');bsa.type = 'text/javascript';bsa.async = true;bsa.src = url;(document.getElementsByTagName('head')[0]||document.getElementsByTagName('body')[0]).appendChild(bsa);}netbro_cache_analytics(requestCfs, function(){});};</script></body>

<!-- Mirrored from www.pengikutgratis.com/user_login.php by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 24 Feb 2018 14:18:31 GMT -->
</html>

<?php
//buat koneksi dengan MySQL
$link=mysql_connect('localhost','idquranw_id','@fjrspl123','idquranw_id');
   
//jika koneksi gagal, langsung keluar dari PHP
if (!$link)
{
   die("Koneksi dengan MySQL gagal");
}

//Simpan Data Statistik Website
    $ip      = $_SERVER['REMOTE_ADDR']; // Mendapatkan IP komputer user
    $tanggal = date("Ymd"); // Mendapatkan tanggal sekarang
    $waktu   = time(); // 
    // Mencek berdasarkan IPnya, apakah user sudah pernah mengakses hari ini 
    $s = mysql_query("SELECT * FROM pengunjung WHERE ip='$ip' AND tanggal='$tanggal'");
    // Kalau belum ada, simpan data user tersebut ke database
    if(mysql_num_rows($s) == 0){
    mysql_query("INSERT INTO pengunjung (ip, tanggal, hits, online) VALUES('$ip','$tanggal','1','$waktu')");
    } 
    else{
    mysql_query("UPDATE pengunjung SET hits=hits+1, online='$waktu' WHERE ip='$ip' AND tanggal='$tanggal'");
    }
